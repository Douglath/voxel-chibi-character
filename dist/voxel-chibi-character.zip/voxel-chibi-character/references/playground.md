# 固定离线游乐场

assets/playground/model-playground.html 是可直接复用的空模板，旁边源码用于维护；不包含用户模型。支持批量 HTML/GLB 导入、表格、角色点击、游乐场漫游及单人统一测试。保留观察台、小花园、暮色庭院、香港街头和自定义 GLB 场景；单人场景选择器同步主题，随机表情按钮立即播放。新模板默认观察台，保存集合后以保存时场景为准。

正式项目：运行现有 scripts/build_html.py，输出指定名称的固定游乐场及同目录 *-dynamics.html 专用动态页。后者保留原模型发裙弹簧及专项测试，前者显示统一跑步/掉落动作。不要声称专用运行时动态已经迁移或烘焙到 GLB。

快速/静态项目：python scripts/build_playground.py --glb character/<id>.glb --output character.html --title 角色名。不必创建骨架；不支持的动作/表情控件禁用。已有兼容离线角色页：改用 --source-html 原角色.html。只解析内嵌 JSON、白名单表情与颜色，不执行导入文件脚本。

首次单模型打开进入单人预览，可返回批量游乐场；保存集合为一个独立 HTML。交付中给出 GLB、源工程、固定 HTML，动态项目另给专用动态 HTML。所有生成脸部仍须无嘴，不在导入器里任意删除陌生用户模型的结构。
